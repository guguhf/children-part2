
(function(compId){var _=null,y=true,n=false,x139='page3-bg3',x133='ellipse',x200='page4-chart',x28='15px',x1='5.0.1',x195='402px',x147='65px',x175='sym-page5-button',x155='547px',x103='85px',x202='357px',x275='Text5',x100='638px',x124='RoundRect5',x31='138px',x90='338px',d='display',x34='536',x152='Text16',x207='rect(246px 101px 246px 0px)',e187='${page5-chart}',x250='439px',x30='541px',x193='page3-bg2',e227='${page4-chart-block2}',x179='media/page5.mp3',x240='347px',e183='${Text16}',x199='628px',x164='228px',e271='${page6-chart}',e7='${sym-page4}',x160='624px',x182='196',x69='329px',zx='scaleX',x126='Text14',x35='0',x49='215px',x110='sym-page3-button',x86='758px',x141='122px',x94='458px',x212='Text15',x159='119px',x3='5.0.1.386',x33='pointer',x22='rgba(0,0,0,1.00)',x72='432px',x130='38px',x51='48px',x283='Text4',x156='521px',x176='225px',x87='sym-2',x118='328',x119='320px',x78='220px',x40='29px',x149='375px',x161='409px',x83='336px',e225='${Text15}',x39='89px',b='block',x29='49px',x125='rgba(0,34,242,1.00)',x280='Text2',e6='${sym-page6}',x233='199',x180='page5',x290='285px',x165='485px',lf='left',x248='rect(0px 0px 61px 0px)',x14='auto',x253='107px',x158='page5-chart',x166='201px',tp='top',x54='rgba(191,239,251,1.00)',e185='${page5-line}',e269='${page6-chart-line1}',x65='rgba(0,0,0,0)',x219='sym-page4-popup',x45='Text6',e224='${page4-chart}',x91='sym-4',x='text',m='rect',x168='rect(0px 0px 201px 0px)',x96='518px',x82='218px',x181='266',x132='Ellipse',x205='246px',x67='346px',x131='50%',l='normal',x52='RoundRect4',x236='Text',x288='274px',x37='574px',e8='${sym-page5}',x26='Text7',x25='break-word',x178='sym-page5-popup',e230='${right-kid2}',x203='282px',cl='clip',x137='12px',x279='22px',x146='783px',x4='horizontal',x189='rect(@@0@@px @@1@@px @@2@@px @@3@@px)',x70='RoundRect3',x261='192px',x217='sym-page4-button',x245='153px',x5='rgba(255,255,255,1)',xc='rgba(0,0,0,1)',e231='${sym-page4-popup}',x144='left-kid2',x95='sym-6',x101='sym-9',e186='${sym-page5-popup}',x111='431',x15='10px',x56='none solid rgb(0, 0, 0)',x206='page4-chart-block1',x243='263px',x194='left-kid',x64='page3-bg',x79='Text10',x62='1024px',p='px',x117='302',x237='199px',x287='542px',x252='360px',x81='sym-1',x216='599px',x167='page5-line',x285='400px',x251='227px',x197='198px',x277='216px',x232='right-kid',x258='477px',x273='rgba(2,152,202,1)',e272='${Text}',x97='sym-7',e270='${page6-chart-line22}',e268='${sym-page6-popup}',x2='5.0.0',x266='true',x174='733px',x265='174',x264='214',x263='page6',x262='media/page6.mp3',x260='sym-page6-popup',x259='sym-page6-button',x274='900',x257='736px',x74='700',x255='rect(0px 0px 107px 0px)',x42='rgba(16,2,247,1.00)',x254='page6-chart-line22',x286='81px',x282='71px',x246='61px',x53='rgb(0, 0, 255)',x247='page6-chart-line1',x244='323px',x88='278px',x104='343px',x234='478px',x108='Text13',x177='197px',x241='page6-chart',x16='rgba(255,255,255,1.00)',x239='626px',x238='113px',x18='rgba(0,0,255,1.00)',x120='45px',x19='solid',x171='228',x17='RoundRect2',x154='200px',i='none',x75='Text9',e229='${left-kid}',x128='46px',x71='rgba(10,26,252,1.00)',x112='460',e228='${page4-chart-block1}',e226='${sym-page4-button}',x77='96px',x57='Text11',x43='none solid rgb(2, 152, 202)',x223='169',x222='373',x134='rgba(255,173,0,1.00)',x20='rgba(0,0,0,0.65098)',x221='page4',x63='768px',x220='media/page4.mp3',x105='Text12',x38='187px',x23='400',x218='273px',x89='sym-3',x215='737px',x115='media/page3.mp3',x214='635px',x44='nowrap',e267='${sym-page6-button}',x150='right-kid3',x210='page4-chart-block2',g='image',x209='623px',x123='160px',x73='97px',x47='9px',x204='101px',x11='20px',x170='298px',x93='sym-5',x138='8px',x59='7px',x102='698px',x48='4px',e9='${sym-page3}',x10='0px',o='opacity',e188='${page5-desc}',x196='right-kid2',x198='180px',zy='scaleY',e184='${sym-page5-button}',x140='161px',x41='RoundRect',x32='sym-page2-popup-close',x172='page5-desc',x98='578px',x84='48',x68='74px',x107='870',x36='38',x163='293px',x21='Arial, Helvetica, sans-serif',x142='105px',x157='44px',x148='137px',x113='160',x55='500',x24='none solid rgb(255, 255, 255)',x135='Text8',x13='223px',w='width',x85='sym-10',x12='563px',x114='audio',x92='398px',x99='sym-8',x116='page3',x143='290px';var g249='page6-chart-line1.png',g151='right-kid.png',g208='page4-chart-block1.png',g256='page6-chart-line2.png',g162='page5-chart.png',g66='page3-bg.png',g242='page6-chart.png',g201='page4-chart.png',g145='left-kid.png',g169='page5-line.png',g173='page5-desc.png',g211='page4-chart-block2.png';var s27="一项包括3项研究的汇总分析，其中2项为成人（15-85岁）研究，1项为儿童（6-14岁）研究，分别纳入436、374和245名慢性哮喘患者，这些患者已经完成双盲、安慰剂对照研究，并分别进入3项扩展性研究，接受口服孟鲁司特（成人10mg，儿童5mg咀嚼片，每日1次）或ICS（成人倍氯米松200μg，每日2次；儿童100μg，每日3次或其他ICS当量）治疗。成人双盲研究为期37周，成人开放性研究为期156周，儿童开放性研究为期112周。儿童研究的主要重点为FEV1和生活质量（9-14岁儿童）。",s61="1",s190="4",s192="7",s60="9",s50="MOSAIC研究是一项多中心、随机、双盲、双模拟、平行分组的非劣效研究，旨在比较口服孟鲁司特5mg qd与吸入氟替卡松100μg bid对哮喘无急救天数的改善。研究共纳入994例6-14岁的轻度持续性哮喘患儿，4周单盲、安慰剂导入期后，患者随机接受口服孟鲁司特5mg qd（若患者年龄满15岁，给予10mg qd, n=495）或吸入氟替卡松100μg bid（n=449）治疗12个月。主要研究终点为1年中哮喘无急救天数比例。若95%CI的下线在-7%以上，则认为孟鲁司特非劣效于氟替卡松。",s281="顺尔宁",s136="X",s276="（孟鲁司特纳 . 默沙东）",s235="6. Williams B, et al. Cl in Exp Allergy. 2001;31(6):845-854.<br>7. Knorr B, et al; Pediatric Montelukast Study Group. JAMA. 1998;279(15):1181-1186.",s46="研究设计",s80="您认可孟鲁司特纳在轻度持续性哮喘治疗中与ICS疗效相当吗？",s291="一项为期52周的多中心、随机、对照的开放性研究，共纳入395例2-8岁的轻度持续性哮喘或反复性哮喘患儿，随机吸入布地奈德0.5mg qd（n=197）或口服孟鲁司特4mg或5mg qd（n=198）治疗52周。轻度哮喘急性发作时，患者每日加用1次布地奈德0.5mg雾化吸入治疗，持续14天，重度发作时，患者接受口服激素治疗，持续3-10天。主要疗效终点为52周内因哮喘急性发作而第一次加用其他哮喘药物的时间。次要终点包括12周和26周时第一次加用其他药物的时间，12周、26周和52周时第一次哮喘发作（轻度和重度）的时间，52周内哮喘发作，日记参数（如呼气峰流速PEF），或者报告的结果和医生、护士的评估。",s289="3",s284="®",s213="4. Garcia ML, et al. Montelukast, Compared with Fluticasone, for the Treatment of Persistent Asthma among 6-to 14-Year-Old Patients with Mild Asthma: The MOSAIC Study. Pediatrics. 2005;116:360-369.",s153="5. Szefler SJ, et al. J Allergy Clin Immunol 2007;120(5):1043-1050.",s122="8",s76="调研问卷",s121="5",s106="不是",s58="6",s109="是",s278="每日一次",s191="10",s127="提   交",s129="2";var im='images/',aud='media/',vid='media/',js='js/',fonts={},opts={'gAudioPreloadPreference':'auto','gVideoPreloadPreference':'auto'},resources=[],scripts=[],symbols={"stage":{v:x1,mv:x2,b:x3,stf:w,cg:x4,rI:n,cn:{dom:[{id:'sym-page3',symbolName:'sym-page3',t:m,r:['0','0','undefined','undefined','auto','auto'],o:'0'},{id:'sym-page4',symbolName:'sym-page4',v:i,t:m,r:['0','0','undefined','undefined','auto','auto']},{id:'sym-page5',symbolName:'sym-page5',v:i,t:m,r:['0','0','undefined','undefined','auto','auto']},{id:'sym-page6',symbolName:'sym-page6',v:i,t:m,r:['0','0','undefined','undefined','auto','auto']},{id:'sym-logo',symbolName:'sym-logo',t:m,r:['-198px','-97px','undefined','undefined','auto','auto'],tf:[[],[],[],['0.24088','0.24088']]}],style:{'${Stage}':{isStage:true,r:['null','null','1024px','768px','auto','auto'],zr:['','1024px','',''],overflow:'hidden',f:[x5]}}},tt:{d:8164.25,a:y,data:[["eid9",d,0,0,"linear",e6,i,i],["eid4",d,0,0,"linear",e7,i,i],["eid7",d,0,0,"linear",e8,i,i],["eid3",o,0,500,"linear",e9,'0','1'],["eid5","tr",0,function(e,d){this.eSA(e,d);},['stop','${sym-page4}',[]]],["eid8","tr",0,function(e,d){this.eSA(e,d);},['stop','${sym-page5}',[]]],["eid10","tr",0,function(e,d){this.eSA(e,d);},['stop','${sym-page6}',[]]]]}},"sym-page6-popup":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{r:[x10,x11,x12,x13,x14,x14],br:[x15,x15,x15,x15],f:[x16],id:x17,s:[1,x18,x19],t:m,boxShadow:['',3,3,3,0,x20]},{n:[x21,[18,p],x22,x23,x24,l,x25,''],t:x,id:x26,text:s27,align:lf,r:[x28,x29,x30,x31,x14,x14]},{t:m,id:x32,sN:x32,cu:x33,r:[x34,x35,x36,x36,x14,x14]}],style:{'${symbolSelector}':{r:[_,_,x37,x38]}}},tt:{d:0,a:y,data:[]}},"sym-page6-button":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{r:[x10,x10,x39,x40,x14,x14],br:[x15,x15,x15,x15],id:x41,s:[0,xc,i],t:m,f:[x42]},{n:[x21,[18,p],x16,x23,x43,l,x25,x44],t:x,id:x45,text:s46,align:lf,r:[x47,x48,x14,x14,x14,x14]}],style:{'${symbolSelector}':{r:[_,_,x39,x40]}}},tt:{d:0,a:y,data:[]}},"sym-page4-popup":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{r:[x10,x11,x12,x49,x14,x14],br:[x15,x15,x15,x15],boxShadow:['',3,3,3,0,x20],id:x17,s:[1,x18,x19],t:m,f:[x16]},{n:[x21,[18,p],x22,x23,x24,l,x25,''],t:x,id:x26,text:s50,align:lf,r:[x28,x29,x30,x31,x14,x14]},{t:m,id:x32,sN:x32,cu:x33,r:[x34,x35,x36,x36,x14,x14]}],style:{'${symbolSelector}':{r:[_,_,x37,x38]}}},tt:{d:0,a:y,data:[]}},"sym-6":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{r:[x10,x10,x51,x51,x14,x14],br:[x15,x15,x15,x15],id:x52,s:[1,x53,i],t:m,f:[x54]},{n:[x21,[30,p],xc,x55,x56,l,x25,x44],t:x,id:x57,text:s58,align:lf,r:[x28,x59,x14,x14,x14,x14]}],style:{'${symbolSelector}':{r:[_,_,x51,x51]}}},tt:{d:0,a:y,data:[]}},"sym-9":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{r:[x10,x10,x51,x51,x14,x14],br:[x15,x15,x15,x15],id:x52,s:[1,x53,i],t:m,f:[x54]},{n:[x21,[30,p],xc,x55,x56,l,x25,x44],t:x,id:x57,text:s60,align:lf,r:[x28,x59,x14,x14,x14,x14]}],style:{'${symbolSelector}':{r:[_,_,x51,x51]}}},tt:{d:0,a:y,data:[]}},"sym-page5-button":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{r:[x10,x10,x39,x40,x14,x14],br:[x15,x15,x15,x15],id:x41,s:[0,xc,i],t:m,f:[x42]},{n:[x21,[18,p],x16,x23,x43,l,x25,x44],t:x,id:x45,text:s46,align:lf,r:[x47,x48,x14,x14,x14,x14]}],style:{'${symbolSelector}':{r:[_,_,x39,x40]}}},tt:{d:0,a:y,data:[]}},"sym-1":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{r:[x10,x10,x51,x51,x14,x14],br:[x15,x15,x15,x15],id:x52,s:[1,x53,i],t:m,f:[x54]},{n:[x21,[30,p],xc,x55,x56,l,x25,x44],t:x,id:x57,text:s61,align:lf,r:[x28,x59,x14,x14,x14,x14]}],style:{'${symbolSelector}':{r:[_,_,x51,x51]}}},tt:{d:0,a:y,data:[]}},"sym-page3":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{r:[x10,x10,x62,x63,x14,x14],id:x64,t:g,f:[x65,im+g66,x10,x10]},{r:[x67,x68,x69,x39,x14,x14],br:[x15,x15,x15,x15],id:x70,s:[1,x53,x19],t:m,f:[x71]},{r:[x72,x73,x14,x14,x14,x14],n:[x21,[40,p],x5,x74,x24,l,x25,x44],id:x75,text:s76,align:lf,t:x},{r:[x77,x78,x14,x14,x14,x14],n:[x21,[30,p],x22,x55,x24,l,x25,x44],id:x79,text:s80,align:lf,t:x},{t:m,id:x81,sN:x81,cu:x33,r:[x82,x83,x84,x84,x14,x14]},{t:m,id:x85,sN:x85,cu:x33,r:[x86,x83,_,_,x14,x14]},{t:m,id:x87,sN:x87,cu:x33,r:[x88,x83,_,_,x14,x14]},{t:m,id:x89,sN:x89,cu:x33,r:[x90,x83,_,_,x14,x14]},{t:m,id:x91,sN:x91,cu:x33,r:[x92,x83,_,_,x14,x14]},{t:m,id:x93,sN:x93,cu:x33,r:[x94,x83,_,_,x14,x14]},{t:m,id:x95,sN:x95,cu:x33,r:[x96,x83,_,_,x14,x14]},{t:m,id:x97,sN:x97,cu:x33,r:[x98,x83,_,_,x14,x14]},{t:m,id:x99,sN:x99,cu:x33,r:[x100,x83,_,_,x14,x14]},{t:m,id:x101,sN:x101,cu:x33,r:[x102,x83,_,_,x14,x14]},{r:[x103,x104,x14,x14,x14,x14],n:[x21,[30,p],xc,x55,x56,l,x25,x44],id:x105,text:s106,align:lf,t:x},{r:[x107,x104,x14,x14,x14,x14],n:[x21,[30,p],xc,x55,x56,l,x25,x44],id:x108,text:s109,align:lf,t:x},{t:m,id:x110,sN:x110,cu:x33,r:[x111,x112,x113,x84,x14,x14]},{pr:x14,t:x114,sr:[x115],id:x116,r:[x117,x118,x119,x120,x14,x14],v:i,tag:x114}],style:{'${symbolSelector}':{r:[_,_,x62,x63]}}},tt:{d:8164.25,a:y,data:[["eid276","tr",1000,function(e,d){this.eMA(e,d);},['play','${page3}',[]]]]}},"sym-5":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{r:[x10,x10,x51,x51,x14,x14],br:[x15,x15,x15,x15],id:x52,s:[1,x53,i],t:m,f:[x54]},{n:[x21,[30,p],xc,x55,x56,l,x25,x44],t:x,id:x57,text:s121,align:lf,r:[x28,x59,x14,x14,x14,x14]}],style:{'${symbolSelector}':{r:[_,_,x51,x51]}}},tt:{d:0,a:y,data:[]}},"sym-8":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{r:[x10,x10,x51,x51,x14,x14],br:[x15,x15,x15,x15],id:x52,s:[1,x53,i],t:m,f:[x54]},{n:[x21,[30,p],xc,x55,x56,l,x25,x44],t:x,id:x57,text:s122,align:lf,r:[x28,x59,x14,x14,x14,x14]}],style:{'${symbolSelector}':{r:[_,_,x51,x51]}}},tt:{d:0,a:y,data:[]}},"sym-page3-button":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{r:[x10,x10,x123,x51,x14,x14],br:[x15,x15,x15,x15],id:x124,s:[1,x53,i],t:m,f:[x125]},{n:[x21,[30,p],x16,x55,x56,l,x25,x44],t:x,id:x126,text:s127,align:lf,r:[x128,x59,x14,x14,x14,x14]}],style:{'${symbolSelector}':{r:[_,_,x123,x51]}}},tt:{d:0,a:y,data:[]}},"sym-2":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{r:[x10,x10,x51,x51,x14,x14],br:[x15,x15,x15,x15],id:x52,s:[1,x53,i],t:m,f:[x54]},{n:[x21,[30,p],xc,x55,x56,l,x25,x44],t:x,id:x57,text:s129,align:lf,r:[x28,x59,x14,x14,x14,x14]}],style:{'${symbolSelector}':{r:[_,_,x51,x51]}}},tt:{d:0,a:y,data:[]}},"sym-page2-popup-close":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{r:[x10,x10,x130,x130,x14,x14],br:[x131,x131,x131,x131],id:x132,s:[1,x53,i],t:x133,f:[x134]},{n:[x21,[20,p],x16,x23,x56,l,x25,x44],t:x,id:x135,text:s136,align:lf,r:[x137,x138,x14,x14,x14,x14]}],style:{'${symbolSelector}':{r:[_,_,x130,x130]}}},tt:{d:0,a:y,data:[]}},"sym-page5":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{r:[x10,x10,x62,x63,x14,x14],id:x139,t:g,f:[x65,im+g66,x10,x10]},{r:[x140,x141,x142,x143,x14,x14],id:x144,t:g,f:[x65,im+g145,x10,x10]},{r:[x146,x147,x148,x149,x14,x14],id:x150,t:g,f:[x65,im+g151,x10,x10]},{t:x,id:x152,text:s153,n:[x21,[12,p],xc,x23,x56,l,x25,''],v:b,r:[x154,x155,x156,x157,x14,x14],o:x35,align:lf},{tf:[[],[],[],[x35,x35]],t:g,id:x158,v:i,r:[x154,x159,x160,x161,x14,x14],f:[x65,im+g162,x10,x10]},{t:g,r:[x163,x164,x165,x166,x14,x14],v:b,id:x167,cl:x168,f:[x65,im+g169,x10,x10]},{t:g,r:[x170,x171,x165,x166,x14,x14],id:x172,o:x35,v:b,f:[x65,im+g173,x10,x10]},{r:[x174,x155,_,_,x14,x14],id:x175,sN:x175,v:b,o:x35,cu:x33,t:m},{r:[x176,x177,_,_,x14,x14],v:i,sN:x178,id:x178,t:m},{pr:x14,t:x114,sr:[x179],id:x180,r:[x181,x182,x119,x120,x14,x14],v:i,tag:x114}],style:{'${symbolSelector}':{r:[_,_,x62,x63]}}},tt:{d:34000,a:y,l:{"page5-playpoint":250},data:[["eid322",d,1000,0,"linear",e183,b,i],["eid335",d,3000,0,"linear",e183,i,b],["eid340",o,3000,500,"linear",e184,'0','1'],["eid320",d,1000,0,"linear",e185,b,i],["eid329",d,1500,0,"linear",e185,i,b],["eid313",d,0,0,"linear",e186,i,i],["eid317",d,1000,0,"linear",e186,i,i],["eid321",d,1000,0,"linear",e187,i,b],["eid328",zy,1000,500,"linear",e187,'0','1'],["eid337",o,3000,500,"linear",e183,'0','1'],["eid318",d,1000,0,"linear",e184,b,i],["eid338",d,3000,0,"linear",e184,i,b],["eid319",d,1000,0,"linear",e188,b,i],["eid332",d,2500,0,"linear",e188,i,b],["eid334",o,2500,500,"linear",e188,'0','1'],["eid331",cl,1500,1000,"linear",e185,[0,0,201,0],[0,485,201,0],{vt:x189}],["eid327",zx,1000,500,"linear",e187,'0','1'],["eid341","tr",2500,function(e,d){this.eMA(e,d);},['play','${page5}',[]]]]}},"sym-4":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{r:[x10,x10,x51,x51,x14,x14],br:[x15,x15,x15,x15],id:x52,s:[1,x53,i],t:m,f:[x54]},{n:[x21,[30,p],xc,x55,x56,l,x25,x44],t:x,id:x57,text:s190,align:lf,r:[x28,x59,x14,x14,x14,x14]}],style:{'${symbolSelector}':{r:[_,_,x51,x51]}}},tt:{d:0,a:y,data:[]}},"sym-10":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{r:[x10,x10,x51,x51,x14,x14],br:[x15,x15,x15,x15],id:x52,s:[1,x53,i],t:m,f:[x54]},{n:[x21,[30,p],xc,x55,x56,l,x25,x44],t:x,id:x57,text:s191,align:lf,r:[x59,x59,x14,x14,x14,x14]}],style:{'${symbolSelector}':{r:[_,_,x51,x51]}}},tt:{d:0,a:y,data:[]}},"sym-7":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{r:[x10,x10,x51,x51,x14,x14],br:[x15,x15,x15,x15],id:x52,s:[1,x53,i],t:m,f:[x54]},{n:[x21,[30,p],xc,x55,x56,l,x25,x44],t:x,id:x57,text:s192,align:lf,r:[x28,x59,x14,x14,x14,x14]}],style:{'${symbolSelector}':{r:[_,_,x51,x51]}}},tt:{d:0,a:y,data:[]}},"sym-page4-button":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{r:[x10,x10,x39,x40,x14,x14],br:[x15,x15,x15,x15],id:x41,s:[0,xc,i],t:m,f:[x42]},{n:[x21,[18,p],x16,x23,x43,l,x25,x44],t:x,id:x45,text:s46,align:lf,r:[x47,x48,x14,x14,x14,x14]}],style:{'${symbolSelector}':{r:[_,_,x39,x40]}}},tt:{d:0,a:y,data:[]}},"sym-page4":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{t:g,id:x193,r:[x10,x10,x62,x63,x14,x14],f:[x65,im+g66,x10,x10]},{t:g,id:x194,r:[x140,x195,x142,x143,x14,x14],f:[x65,im+g145,x10,x10]},{t:g,id:x196,r:[x146,x147,x148,x149,x14,x14],f:[x65,im+g151,x10,x10]},{t:g,tf:[[],[],[],[x35,x35]],v:b,r:[x197,x198,x199,x161,x14,x14],id:x200,f:[x65,im+g201,x10,x10]},{r:[x202,x203,x204,x205,x14,x14],t:g,id:x206,v:b,cl:x207,f:[x65,im+g208,x10,x10]},{r:[x209,x203,x204,x205,x14,x14],t:g,id:x210,v:b,cl:x207,f:[x65,im+g211,x10,x10]},{t:x,id:x212,text:s213,r:[x197,x214,x199,x130,x14,x14],v:b,align:lf,n:[x21,[12,p],x22,x23,x24,l,x25,''],o:x35},{r:[x215,x216,_,_,x14,x14],t:m,o:x35,v:b,sN:x217,cu:x33,id:x217},{r:[x176,x218,_,_,x14,x14],id:x219,sN:x219,t:m,v:i},{pr:x14,t:x114,sr:[x220],id:x221,r:[x222,x223,x119,x120,x14,x14],v:i,tag:x114}],style:{'${symbolSelector}':{r:[_,_,x62,x63]}}},tt:{d:30000,a:n,l:{"play-point":250},data:[["eid281",d,0,0,"linear",e224,b,i],["eid287",d,3250,0,"linear",e224,i,b],["eid284",d,0,0,"linear",e225,b,i],["eid305",d,4750,0,"linear",e225,i,b],["eid309",o,4750,500,"linear",e226,'0','1'],["eid304",cl,3750,1000,"linear",e227,[246,101,246,0],[0,101,246,0],{vt:x189}],["eid293",zy,3250,500,"linear",e224,'0','1'],["eid286",d,0,0,"linear",e228,b,i],["eid294",d,3750,0,"linear",e228,i,b],["eid307",o,4750,500,"linear",e225,'0','1'],["eid279",tp,250,3000,"linear",e229,'402px','122px'],["eid297",cl,3750,1000,"linear",e228,[246,101,246,0],[0,101,246,0],{vt:x189}],["eid292",zx,3250,500,"linear",e224,'0','1'],["eid280",tp,250,3000,"linear",e230,'335px','65px'],["eid282",d,0,0,"linear",e231,i,i],["eid285",d,0,0,"linear",e227,b,i],["eid298",d,3750,0,"linear",e227,i,b],["eid283",d,0,0,"linear",e226,b,i],["eid308",d,4750,0,"linear",e226,i,b],["eid310","tr",3750,function(e,d){this.eMA(e,d);},['play','${page4}',[]]]]}},"sym-page6":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{id:x64,t:g,r:[x10,x10,x62,x63,x14,x14],f:[x65,im+g66,x10,x10]},{id:x232,t:g,r:[x146,x147,x148,x149,x14,x14],f:[x65,im+g151,x10,x10]},{n:[x21,[12,p],xc,x23,x56,l,x25,x44],r:[x233,x234,x14,x14,x14,x14],align:lf,text:s235,id:x236,o:x35,v:b,t:x},{id:x194,t:g,r:[x140,x141,x142,x143,x14,x14],f:[x65,im+g145,x10,x10]},{r:[x237,x238,x239,x240,x14,x14],tf:[[],[],[],[x35,x35]],id:x241,t:g,v:b,f:[x65,im+g242,x10,x10]},{r:[x243,x244,x245,x246,x14,x14],t:g,id:x247,v:b,cl:x248,f:[x65,im+g249,x10,x10]},{r:[x250,x251,x252,x253,x14,x14],t:g,id:x254,v:b,cl:x255,f:[x65,im+g256,x10,x10]},{t:m,o:x35,r:[x257,x258,_,_,x14,x14],v:b,sN:x259,cu:x33,id:x259},{t:m,v:i,sN:x260,r:[x176,x261,_,_,x14,x14],id:x260},{pr:x14,t:x114,sr:[x262],id:x263,r:[x264,x265,x119,x120,x14,x14],v:i,tag:x114}],style:{'${symbolSelector}':{isStage:x266,r:[undefined,undefined,x62,x63]}}},tt:{d:18281,a:y,l:{"page6-playpoint":500},data:[["eid347",d,500,0,"linear",e267,b,i],["eid365",d,3500,0,"linear",e267,i,b],["eid344",d,500,0,"linear",e268,i,i],["eid361",cl,2000,500,"linear",e269,[0,0,61,0],[0,153,61,0],{vt:x189}],["eid348",d,500,0,"linear",e270,b,i],["eid362",d,2500,0,"linear",e270,i,b],["eid350",d,500,0,"linear",e271,b,i],["eid352",d,1500,0,"linear",e271,i,b],["eid357",zx,1500,500,"linear",e271,'0','1'],["eid351",d,500,0,"linear",e272,b,i],["eid368",d,3500,0,"linear",e272,i,b],["eid364",cl,2500,1000,"linear",e270,[0,0,107,0],[0,360,107,0],{vt:x189}],["eid367",o,3500,500,"linear",e267,'0','1'],["eid349",d,500,0,"linear",e269,b,i],["eid359",d,2000,0,"linear",e269,i,b],["eid358",zy,1500,500,"linear",e271,'0','1'],["eid370",o,3500,500,"linear",e272,'0','1'],["eid371","tr",2000,function(e,d){this.eMA(e,d);},['play','${page6}',[]]]]}},"sym-logo":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{n:[x21,[50,p],x273,x274,x43,l,x25,x44],t:x,id:x275,text:s276,align:lf,r:[x10,x277,x14,x14,x14,x14]},{n:[x21,[50,p],x273,x274,x43,l,x25,x44],t:x,id:x236,text:s278,align:lf,r:[x279,x10,x14,x14,x14,x14]},{n:[x21,[120,p],x273,x274,x43,l,x25,x44],t:x,id:x280,text:s281,align:lf,r:[x279,x282,x14,x14,x14,x14]},{n:[x21,[50,p],x273,x274,x43,l,x25,x44],t:x,id:x283,text:s284,align:lf,r:[x285,x286,x14,x14,x14,x14]}],style:{'${symbolSelector}':{r:[_,_,x287,x288]}}},tt:{d:0,a:y,data:[]}},"sym-3":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{r:[x10,x10,x51,x51,x14,x14],br:[x15,x15,x15,x15],id:x52,s:[1,x53,i],t:m,f:[x54]},{n:[x21,[30,p],xc,x55,x56,l,x25,x44],t:x,id:x57,text:s289,align:lf,r:[x28,x59,x14,x14,x14,x14]}],style:{'${symbolSelector}':{r:[_,_,x51,x51]}}},tt:{d:0,a:y,data:[]}},"sym-page5-popup":{v:x1,mv:x2,b:x3,stf:i,cg:i,rI:n,cn:{dom:[{r:[x10,x11,x12,x290,x14,x14],br:[x15,x15,x15,x15],f:[x16],id:x17,s:[1,x18,x19],t:m,boxShadow:['',3,3,3,0,x20]},{r:[x28,x29,x30,x31,x14,x14],n:[x21,[18,p],x22,x23,x24,l,x25,''],id:x26,text:s291,align:lf,t:x},{t:m,id:x32,sN:x32,cu:x33,r:[x34,x35,x36,x36,x14,x14]}],style:{'${symbolSelector}':{r:[_,_,x37,x38]}}},tt:{d:0,a:y,data:[]}}};AdobeEdge.registerCompositionDefn(compId,symbols,fonts,scripts,resources,opts);})("EDGE-191161658");
(function($,Edge,compId){var Composition=Edge.Composition,Symbol=Edge.Symbol;Edge.registerEventBinding(compId,function($){
//Edge symbol: 'stage'
(function(symbolName){})("stage");
//Edge symbol end:'stage'

//=========================================================

//=========================================================

//Edge symbol: 'sym-logo'
(function(symbolName){})("sym-logo");
//Edge symbol end:'sym-logo'

//=========================================================

//Edge symbol: 'sym-1_7'
(function(symbolName){})("sym-8");
//Edge symbol end:'sym-8'

//=========================================================

//Edge symbol: 'sym-page2-popup_1'
(function(symbolName){Symbol.bindElementAction(compId,symbolName,"${sym-page2-popup-close}","click",function(sym,e){sym.getSymbolElement().hide();});
//Edge binding end
})("sym-page4-popup");
//Edge symbol end:'sym-page4-popup'

//=========================================================

//Edge symbol: 'sym-1_5'
(function(symbolName){})("sym-6");
//Edge symbol end:'sym-6'

//=========================================================

//Edge symbol: 'sym-1_8'
(function(symbolName){})("sym-9");
//Edge symbol end:'sym-9'

//=========================================================

//Edge symbol: 'sym-page2-button_1'
(function(symbolName){})("sym-page5-button");
//Edge symbol end:'sym-page5-button'

//=========================================================

//Edge symbol: 'sym-1'
(function(symbolName){})("sym-1");
//Edge symbol end:'sym-1'

//=========================================================

//Edge symbol: 'sym-page2-button_1'
(function(symbolName){})("sym-page6-button");
//Edge symbol end:'sym-page6-button'

//=========================================================

//Edge symbol: 'sym-1_4'
(function(symbolName){})("sym-5");
//Edge symbol end:'sym-5'

//=========================================================

//Edge symbol: 'sym-page2-popup_1'
(function(symbolName){Symbol.bindElementAction(compId,symbolName,"${sym-page2-popup-close}","click",function(sym,e){sym.getSymbolElement().hide();});
//Edge binding end
})("sym-page6-popup");
//Edge symbol end:'sym-page6-popup'

//=========================================================

//Edge symbol: 'sym-page3-button'
(function(symbolName){})("sym-page3-button");
//Edge symbol end:'sym-page3-button'

//=========================================================

//Edge symbol: 'sym-1_1'
(function(symbolName){})("sym-2");
//Edge symbol end:'sym-2'

//=========================================================

//Edge symbol: 'sym-page6'
(function(symbolName){Symbol.bindElementAction(compId,symbolName,"${sym-page6-button}","click",function(sym,e){sym.$("sym-page6-popup").show();});
//Edge binding end
})("sym-page6");
//Edge symbol end:'sym-page6'

//=========================================================

//Edge symbol: 'sym-page5'
(function(symbolName){Symbol.bindElementAction(compId,symbolName,"${sym-page5-button}","click",function(sym,e){sym.$("sym-page5-popup").show();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",34000,function(sym,e){sym.stop();sym.$("page5")[0].pause();sym.getSymbolElement().hide();sym.getComposition().getStage().$("sym-page6").show();sym.getComposition().getStage().getSymbol("sym-page6").play("page6-playpoint");});
//Edge binding end
})("sym-page5");
//Edge symbol end:'sym-page5'

//=========================================================

//Edge symbol: 'sym-page4-popup_1'
(function(symbolName){Symbol.bindElementAction(compId,symbolName,"${sym-page2-popup-close}","click",function(sym,e){sym.getSymbolElement().hide();});
//Edge binding end
})("sym-page5-popup");
//Edge symbol end:'sym-page5-popup'

//=========================================================

//Edge symbol: 'sym-1_9'
(function(symbolName){})("sym-10");
//Edge symbol end:'sym-10'

//=========================================================

//Edge symbol: 'sym-1_6'
(function(symbolName){})("sym-7");
//Edge symbol end:'sym-7'

//=========================================================

//Edge symbol: 'sym-page4'
(function(symbolName){Symbol.bindElementAction(compId,symbolName,"${sym-page4-button}","click",function(sym,e){sym.$("sym-page4-popup").show();});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",30000,function(sym,e){sym.stop();sym.$("page4")[0].pause();sym.getSymbolElement().hide();sym.getComposition().getStage().$("sym-page5").show();sym.getComposition().getStage().getSymbol("sym-page5").play("page5-playpoint");});
//Edge binding end
})("sym-page4");
//Edge symbol end:'sym-page4'

//=========================================================

//Edge symbol: 'sym-page2-button_1'
(function(symbolName){})("sym-page4-button");
//Edge symbol end:'sym-page4-button'

//=========================================================

//Edge symbol: 'sym-1_3'
(function(symbolName){})("sym-4");
//Edge symbol end:'sym-4'

//=========================================================

//Edge symbol: 'sym-page2-popup-close'
(function(symbolName){})("sym-page2-popup-close");
//Edge symbol end:'sym-page2-popup-close'

//=========================================================

//Edge symbol: 'sym-1_2'
(function(symbolName){})("sym-3");
//Edge symbol end:'sym-3'

//=========================================================

//Edge symbol: 'sym-page3'
(function(symbolName){Symbol.bindTimelineAction(compId,symbolName,"Default Timeline","play",function(sym,e){var intNumber=0;});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${sym-1}","click",function(sym,e){for(i=1;i<=10;i++){sym.getSymbol("sym-"+i+"").$("RoundRect4").css("background-color","#bfeffb");sym.getSymbol("sym-"+i+"").$("Text11").css("color","#000");}
sym.getSymbol("sym-1").$("RoundRect4").css("background-color","#0022f2");sym.getSymbol("sym-1").$("Text11").css("color","#FFF");intNumber=1;});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${sym-2}","click",function(sym,e){for(i=1;i<=10;i++){sym.getSymbol("sym-"+i+"").$("RoundRect4").css("background-color","#bfeffb");sym.getSymbol("sym-"+i+"").$("Text11").css("color","#000");}
sym.getSymbol("sym-2").$("RoundRect4").css("background-color","#0022f2");sym.getSymbol("sym-2").$("Text11").css("color","#FFF");intNumber=2;});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${sym-3}","click",function(sym,e){for(i=1;i<=10;i++){sym.getSymbol("sym-"+i+"").$("RoundRect4").css("background-color","#bfeffb");sym.getSymbol("sym-"+i+"").$("Text11").css("color","#000");}
sym.getSymbol("sym-3").$("RoundRect4").css("background-color","#0022f2");sym.getSymbol("sym-3").$("Text11").css("color","#FFF");intNumber=3;});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${sym-4}","click",function(sym,e){for(i=1;i<=10;i++){sym.getSymbol("sym-"+i+"").$("RoundRect4").css("background-color","#bfeffb");sym.getSymbol("sym-"+i+"").$("Text11").css("color","#000");}
sym.getSymbol("sym-4").$("RoundRect4").css("background-color","#0022f2");sym.getSymbol("sym-4").$("Text11").css("color","#FFF");intNumber=4;});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${sym-5}","click",function(sym,e){for(i=1;i<=10;i++){sym.getSymbol("sym-"+i+"").$("RoundRect4").css("background-color","#bfeffb");sym.getSymbol("sym-"+i+"").$("Text11").css("color","#000");}
sym.getSymbol("sym-5").$("RoundRect4").css("background-color","#0022f2");sym.getSymbol("sym-5").$("Text11").css("color","#FFF");intNumber=5;});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${sym-6}","click",function(sym,e){for(i=1;i<=10;i++){sym.getSymbol("sym-"+i+"").$("RoundRect4").css("background-color","#bfeffb");sym.getSymbol("sym-"+i+"").$("Text11").css("color","#000");}
sym.getSymbol("sym-6").$("RoundRect4").css("background-color","#0022f2");sym.getSymbol("sym-6").$("Text11").css("color","#FFF");intNumber=6;});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${sym-7}","click",function(sym,e){for(i=1;i<=10;i++){sym.getSymbol("sym-"+i+"").$("RoundRect4").css("background-color","#bfeffb");sym.getSymbol("sym-"+i+"").$("Text11").css("color","#000");}
sym.getSymbol("sym-7").$("RoundRect4").css("background-color","#0022f2");sym.getSymbol("sym-7").$("Text11").css("color","#FFF");intNumber=7;});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${sym-8}","click",function(sym,e){for(i=1;i<=10;i++){sym.getSymbol("sym-"+i+"").$("RoundRect4").css("background-color","#bfeffb");sym.getSymbol("sym-"+i+"").$("Text11").css("color","#000");}
sym.getSymbol("sym-8").$("RoundRect4").css("background-color","#0022f2");sym.getSymbol("sym-8").$("Text11").css("color","#FFF");intNumber=8;});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${sym-9}","click",function(sym,e){for(i=1;i<=10;i++){sym.getSymbol("sym-"+i+"").$("RoundRect4").css("background-color","#bfeffb");sym.getSymbol("sym-"+i+"").$("Text11").css("color","#000");}
sym.getSymbol("sym-9").$("RoundRect4").css("background-color","#0022f2");sym.getSymbol("sym-9").$("Text11").css("color","#FFF");intNumber=9;});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${sym-10}","click",function(sym,e){for(i=1;i<=10;i++){sym.getSymbol("sym-"+i+"").$("RoundRect4").css("background-color","#bfeffb");sym.getSymbol("sym-"+i+"").$("Text11").css("color","#000");}
sym.getSymbol("sym-10").$("RoundRect4").css("background-color","#0022f2");sym.getSymbol("sym-10").$("Text11").css("color","#FFF");intNumber=10;});
//Edge binding end
Symbol.bindElementAction(compId,symbolName,"${sym-page3-button}","click",function(sym,e){if(intNumber>=1){sym.stop();sym.$("page3")[0].pause();sym.getSymbolElement().hide();sym.getComposition().getStage().$("sym-page4").show();sym.getComposition().getStage().getSymbol("sym-page4").play("play-point");}});
//Edge binding end
})("sym-page3");
//Edge symbol end:'sym-page3'
})})(AdobeEdge.$,AdobeEdge,"EDGE-191161658");